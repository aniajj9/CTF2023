# Reversed

To run this server, make sure you have docker installed and issue the following command 'docker compose up'.

This will give you a server similarly to the one on the remote server - only difference is the flag.