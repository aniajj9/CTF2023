package com.kalmarunionen.calculator;

import java.sql.*;

public class DatabaseCalculatorImpl implements CalculatorService, AutoCloseable
{
    private final Connection conn;

    public DatabaseCalculatorImpl() throws Exception
    {
        conn = DriverManager.getConnection(
            System.getenv("DATABASE_URI"), 
            System.getenv("DATABASE_USER"), 
            System.getenv("DATABASE_PASSWORD"));
    }

    public String calculate(String expression) throws Exception
    {
        String escapedSql = String.format("SELECT %s as result", expression);
        try (PreparedStatement statement = conn.prepareStatement(escapedSql))
        {
            ResultSet resultSet = statement.executeQuery();
            return (resultSet.next() ? resultSet.getString(1) : "Failed to calculate");
        } catch(Exception e){
            return "Exception: " + e.getMessage();
        }
    }

    @Override
    public void close() throws Exception {
        conn.close();
    }
}