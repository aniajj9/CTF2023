package com.kalmarunionen.calculator;

public interface CalculatorService 
{
    public String calculate(String expression) throws Exception;
}