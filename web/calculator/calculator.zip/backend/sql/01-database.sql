CREATE TABLE IF NOT EXISTS void.flags (flag TEXT, origin TEXT);

INSERT INTO void.flags (`flag`, `origin`) VALUES ('CTF{sample}', 'unknown');

/* ... */